<?php
	$fname= "";
	$err_fname= "";
	$lname= "";
	$err_lname= "";
	$gender= "";
	$err_gender= "";
	$date="";
	$err_date="";
	$paddress= "";
	$err_paddress= "";
	$paraddress= "";
	$err_paraddress= "";
	$email = "";
	$err_email = "";
	$phone= "";
	$err_phone="";
	$pweb="";
	$err_pweb="";
	$uname = "";
	$err_uname="";
	$pass= "";
	$err_pass= "";
		

	 if(isset($_POST["submit"]))
	 {
		if(empty($_POST["fname"]))
		{
			$err_fname="[First Name Required]";
			$hasError = true;
		}
		else 
		{
			$fname=$_POST["fname"];
		}

		if(empty($_POST["lname"]))
		{
			$err_lname="[Last Name Required]";
			$hasError = true;
		}
		else 
		{
			$lname=$_POST["lname"];
		}

		if(!isset($_POST["gender"]))
		 {
			 $err_gender="[Please select a gender]";
			 $hasError = true;
		 }
		 else
		 {
			 $gender=$_POST["gender"];
		 }

		 if(empty($_POST["date"]))
		{
			$err_date="[Date Required]";
			$hasError = true;
		}
		else 
		{
			$date=$_POST["date"];
		}

		if(empty($_POST["lname"]))
		{
			$err_lname="[Last Name Required]";
			$hasError = true;
		}
		else 
		{
			$lname=$_POST["lname"];
		}
	




		if(empty($_POST["paddress"]))
		{
			$err_paddress="[Present Address Required]";
			$hasError = true;
		}
		else 
		{
			$paddress=$_POST["paddress"];
		}

		if(empty($_POST["paraddress"]))
		{
			$err_paraddress="[Parmanent Address Required]";
			$hasError = true;
		}
		else 
		{
			$paraddress=$_POST["paraddress"];
		}
		
		if(empty($_POST["email"]))
		 {
			 $err_email="[Email Required]";
			 $hasError = true;
		 }else{
			 $email=htmlspecialchars($_POST["email"]);
		 }
		if(empty($_POST["phone"]))
		{
			$err_phone="[Phone Number Required]";
			$hasError = true;
		}else
		{
			$phone=$_POST["phone"];
		}
		if(empty($_POST["pweb"]))
		{
			$err_pweb="[Personal Web Link Required]";
			$hasError = true;
		}
		else 
		{
			$pweb=$_POST["pweb"];
		}



		if(empty($_POST["uname"]))
		{
			$err_uname="[Username Required]";
			$hasError = true;
		}
		else 
		{
			$uname=$_POST["uname"];
		}

		if(empty($_POST["pass"]))
		{
			$err_pass="[Password Required]";
			$hasError = true;
		}
		else 
		{
			$pass=$_POST["pass"];
		}
	}

$fname= "";
	$err_fname= "";
	$lname= "";
	$err_lname= "";
	$gender= "";
	$err_gender= "";
	$date="";
	$err_date="";
	$paddress= "";
	$err_paddress= "";
	$paraddress= "";
	$err_paraddress= "";
	$email = "";
	$err_email = "";
	$phone= "";
	$err_phone="";
	$pweb="";
	$err_pweb="";
	$uname = "";
	$err_uname="";
	$pass= "";
	$err_pass= "";


		function insertUser($fname,$lname,$gender,$date,$paddress,$paraddress,$email,$phone,$pweb,$uname,$pass)
		{
             $query="INSERT INTO `registration` (`fname`,'lname','gender','date','paddress', 'paraddress','email','phone','pweb','uname','pass' ) VALUES (NULL,	'$fname','$lname','$gender','$date','$paddress','$paraddress','email','$phone','$pweb','$uname','$pass');";
             execute($query);
		}


		
		
		function checkUsername($username){
		$query = "select * from seller_add where uname='$username'";
		$result = get($query);
		if(count($result) > 0){
			return false;
		}
		return true;		
	}
?>		

		
		
		
		
		
		
		


<html>
	<head>
		<style>
			 body{
			 background-color:gray;
			 }
		</style>
	</head>
	<body>
		<h1>Registration Form</h1>
		<form action=""  onsubmit="return validate()" method="post">
		<fieldset>
		<legend><b><h2>Basic Information</h2></b></legend>
			<table>
				<tr>
					<td><span><b>First name</b>:</span></td>
					<td>:<input type="text" name="fname" value = "<?php echo $fname;?>" ><br>
					<td><span><?php echo $err_fname;?></span></td>
				</tr>

				<tr>
					<td><span><b>Last name</b>:</span></td>
					<td>:<input type="text" name="lname" value = "<?php echo $lname;?>" ><br>
					<td><span><?php echo $err_lname;?></span></td>
				</tr>
				<tr>
					<td><span><b>Gender</b></span></td>
					<td>:<input type="radio" name="gender" id="male" value="Male"><span>Male</span>
					    <input type="radio" name="gender" id="female" value="Female"><span>Female</span>
						<span id="err_gender" ><?php echo "&nbsp ".$err_gender;?></span></td>
				</tr>
				<tr>
					<td><span><b>Date</b></span></td>
					<td>:<input type="date" name="date" value="<?php echo $Date;?>" ><br>
					<td><span><?php echo $err_date;?></span></td>
				</tr>
			</table>
			
			
			
		
		
		<legend><b><h2>Contract Information</h2></b></legend>

		
			<table>
				<tr>
					<td><span><b>Present address</b>:</span></td>
					<td>:<input type="text" name="paddress" value = "<?php echo $paddress;?>" ><br>
					<td><span><?php echo $err_paddress;?></span></td>
				</tr>
				<tr>
					<td><span><b>Permanent address</b>:</span></td>
					<td>:<input type="text" name="paraddress" value = "<?php echo $paraddress;?>" ><br>
					<td><span><?php echo $err_paraddress;?></span></td>
				</tr>
				<tr>
					<td><span><b>Email</b>:</span></td>
					<td>:<input type="text" name="email" value = "<?php echo $email;?>" ><br>
					<td><span><?php echo $err_email;?></span></td>
				</tr>
				<tr>
					<td><span><b>Phone</b>:</span></td>
					<td>:<input type="text" name="phone" value = "<?php echo $phone;?>" ><br>
					<td><span><?php echo $err_phone;?></span></td>
				</tr>
				<tr>
					<td><span><b>Personal Website Link</b>:</span></td>
					<td>:<input type="link" name="pweb" value="<?php echo $pweb ?>" ><br>
					<td><span><?php echo $err_pweb ?></span></td>	
					</tr>
			</table>
		
	
		
		
		
		
		
		<legend><h2><b>Academic Information</h2></b></legend>
		

		
			<table>
				<tr>
					<td><span><b>Username</b>:</span></td>
					<td><input type="text" name="uname" value = "<?php echo $uname;?>" ><br>
					<td><span><?php echo $err_uname;?></span></td>
				</tr>
				<table>
				<tr>
					<td><span><b>Password</b>:</span></td>
					<td><input type="password" name="pass" value = "<?php echo $pass;?>"><br>
					<td><span><?php echo $err_pass;?></span></td>
				</tr>
			</table>			
		</fieldset>
		
		
		
		
		<center><input type="submit" name="submit" value="Register"></center>
		</form>
	</body>
</html> 


<html>
	<head>
		<style>
			 body{
			 background-color:#20B2AA;
			 }
						 a:link, a:visited {
			  background-color: blue;
			  color: white;
			  padding: 14px 25px;
			  text-align: center;
			  text-decoration: none;
			  display: inline-block;
			}

			a:hover, a:active {
			  background-color: red;
			}
		</style>
	</head>
			<body>
				<br><a href="login.php"<b>login</b></a></br>
			</body>
</html>